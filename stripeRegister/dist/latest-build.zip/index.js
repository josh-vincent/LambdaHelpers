/* Amplify Params - DO NOT EDIT
	AUTH_FINANCEWEBAPP97F25861_USERPOOLID
	ENV
	REGION
Amplify Params - DO NOT EDIT */
const AWS = require("aws-sdk");
AWS.config.update({ region: "ap-southeast-2" });
const docClient = new AWS.DynamoDB.DocumentClient();
const COGNITO = new AWS.CognitoIdentityServiceProvider({ apiVersion: "2016-04-18" });
const stripeTest = require("stripe")("sk_test_ubDVscDUXB04y842N53sxWjh00advqWqiU");
const stripe = require("stripe")("sk_live_pGMoYL65V4KEDT0cT8uJESHV00bv0VCBip");
const TABLE_NAME = `Profile-6lalkwvyozdkpai7v232is3yfe-${process.env.ENV}`;

exports.handler = async (event, context, callback) =>
{
    const { userName, userPoolId } = event;
    const { request: { userAttributes } } = event;
    console.log(JSON.stringify(event));
    try
    {
        // no callback here
        const stripeUser = await createUserInStripe(userAttributes);
        console.log(stripeUser);

        const value = { stripe_id: stripeUser.id };
        const updatedUser = await updateCognito(userPoolId, userName, value);
        //const updatedTable = await updateTable(userAttributes, stripeUser.id); //!Fix this currently updating before profiles created, only update after profiles created
        console.log(updatedUser);
        //console.log(updatedTable);

        const response = {
            statusCode: 200,
            body: JSON.stringify("Created Stripe User!"),
        };
        callback(null, event);
        return response;
    } catch (error)
    {
        console.error("error", error);
        const response = {
            statusCode: 500,
            body: JSON.stringify("Error adding Stripe User"),
        };
        return response;
    }
};

async function createUserInStripe(data)
{
    console.log("adding to stripe:", data);
    const { username, email, sub } = data;
    const createdUser = await stripeTest.customers
        .create({
            name: username,
            email: email,
            description: sub,
        })
        .then((result) =>
        {
            console.log("result", result);
            return result;
        })
        .catch((err) => console.log("err", err));
    return createdUser;
}

const updateCognito = async (userPoolId, userName, value) =>
{
    const updatedUser = await COGNITO.adminUpdateUserAttributes({
        UserAttributes: [
            {
                Name: `custom:stripe_id`,
                Value: value.stripe_id,
            },
        ],
        UserPoolId: userPoolId,
        Username: userName,
    }).promise();
    return updatedUser;
};


const updateTable = async (userAttributes, stripeId) =>
{
    const timestamp = new Date().toISOString();
    console.log("updating profile table:", userAttributes, stripeId);
    var inputParams = {
        TableName: TABLE_NAME,
        Key: {
            id: userAttributes.sub,
        },
        UpdateExpression: "SET #stripe = :stripe, #uA = :ua",
        ExpressionAttributeValues: {
            ":stripe": stripeId,
            ":ua": timestamp,
        },
        ExpressionAttributeNames: {
            "#stripe": "stripe_id",
            "#uA": "updatedAt",
        },
    };

    let response = docClient.update(inputParams).promise();
    return response;
};
